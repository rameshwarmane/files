from pythonproject.string.funcstring import StringFunc


def test_remove_spaces():
    strfn = StringFunc()
    assert strfn.remove_spaces(" lead_trail_space_str ") == "lead_trail_space_str"


def test_remove_chars():
    strfn = StringFunc()
    assert strfn.remove_chars("open/insights", "/", "-") == "open-insights"
