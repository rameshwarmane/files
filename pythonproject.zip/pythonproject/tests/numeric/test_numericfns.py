from pythonproject.numeric.funcnumeric import NumericFuncs


def test_sum():
    numfn = NumericFuncs()
    assert numfn.sum(34, 34) == 68


def test_diff():
    numfn = NumericFuncs()
    assert numfn.diff(34, 34) == 0


def test_prod():
    numfn = NumericFuncs()
    assert numfn.prod(25, 25) == 625
