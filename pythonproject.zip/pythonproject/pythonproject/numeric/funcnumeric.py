class NumericFuncs:
    def sum(self, left: int, right: int) -> int:
        return left + right

    def diff(self, left: int, right: int) -> int:
        return left - right

    def prod(self, left: int, right: int) -> int:
        return left * right
