class StringFunc:
    def remove_spaces(self, s: str) -> str:
        return s.strip()

    def remove_chars(self, s: str, chars: str, repstr: str) -> str:
        return s.replace(chars, repstr)
